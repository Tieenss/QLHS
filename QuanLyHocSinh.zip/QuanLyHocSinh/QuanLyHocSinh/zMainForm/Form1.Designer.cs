﻿namespace QuanLyHocSinh.zMainForm
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip2 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.đăngXuấtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thoátToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quảnLýLớpHọcToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quảnLýGiáoViênToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quảnLýTổBộMônToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.đàoTạoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quảnLýMônHọcToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thờiKhóaBiểuVàLịchDạyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.phòngHọcVàThiếtBịToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.khảoThíVàKếtQuảToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quảnLýĐiểmSốToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hạnhKiểmVàRènLuyệnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lịchThiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hànhChínhVàTàiVụToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quảnLýHọcPhíToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quảnLýThôngBáoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quảnLýPhúcKhảoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hệThốngVàChínhSáchToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quảnLýHọcSinhToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quảnLýĐốiTượngƯuTiênToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quảnLýTàiKhoảnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.label1 = new System.Windows.Forms.Label();
            this.menuStrip2.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip2
            // 
            this.menuStrip2.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.editToolStripMenuItem,
            this.đàoTạoToolStripMenuItem,
            this.khảoThíVàKếtQuảToolStripMenuItem,
            this.hànhChínhVàTàiVụToolStripMenuItem,
            this.hệThốngVàChínhSáchToolStripMenuItem});
            this.menuStrip2.Location = new System.Drawing.Point(0, 0);
            this.menuStrip2.Name = "menuStrip2";
            this.menuStrip2.Padding = new System.Windows.Forms.Padding(4, 2, 0, 2);
            this.menuStrip2.Size = new System.Drawing.Size(1264, 24);
            this.menuStrip2.TabIndex = 1;
            this.menuStrip2.Text = "menuStrip2";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.đăngXuấtToolStripMenuItem,
            this.thoátToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(69, 20);
            this.fileToolStripMenuItem.Text = "Hệ thống";
            // 
            // đăngXuấtToolStripMenuItem
            // 
            this.đăngXuấtToolStripMenuItem.Name = "đăngXuấtToolStripMenuItem";
            this.đăngXuấtToolStripMenuItem.Size = new System.Drawing.Size(129, 22);
            this.đăngXuấtToolStripMenuItem.Text = "Đăng Xuất";
            this.đăngXuấtToolStripMenuItem.Click += new System.EventHandler(this.đăngXuấtToolStripMenuItem_Click);
            // 
            // thoátToolStripMenuItem
            // 
            this.thoátToolStripMenuItem.Name = "thoátToolStripMenuItem";
            this.thoátToolStripMenuItem.Size = new System.Drawing.Size(129, 22);
            this.thoátToolStripMenuItem.Text = "Thoát";
            this.thoátToolStripMenuItem.Click += new System.EventHandler(this.thoátToolStripMenuItem_Click);
            // 
            // editToolStripMenuItem
            // 
            this.editToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.quảnLýLớpHọcToolStripMenuItem,
            this.quảnLýGiáoViênToolStripMenuItem,
            this.quảnLýTổBộMônToolStripMenuItem});
            this.editToolStripMenuItem.Name = "editToolStripMenuItem";
            this.editToolStripMenuItem.Size = new System.Drawing.Size(105, 20);
            this.editToolStripMenuItem.Text = "Hồ sơ và Cơ cấu";
            // 
            // quảnLýLớpHọcToolStripMenuItem
            // 
            this.quảnLýLớpHọcToolStripMenuItem.Name = "quảnLýLớpHọcToolStripMenuItem";
            this.quảnLýLớpHọcToolStripMenuItem.Size = new System.Drawing.Size(174, 22);
            this.quảnLýLớpHọcToolStripMenuItem.Text = "Quản lý lớp học";
            this.quảnLýLớpHọcToolStripMenuItem.Click += new System.EventHandler(this.quảnLýLớpHọcToolStripMenuItem_Click);
            // 
            // quảnLýGiáoViênToolStripMenuItem
            // 
            this.quảnLýGiáoViênToolStripMenuItem.Name = "quảnLýGiáoViênToolStripMenuItem";
            this.quảnLýGiáoViênToolStripMenuItem.Size = new System.Drawing.Size(174, 22);
            this.quảnLýGiáoViênToolStripMenuItem.Text = "Quản lý giáo viên";
            this.quảnLýGiáoViênToolStripMenuItem.Click += new System.EventHandler(this.quảnLýGiáoViênToolStripMenuItem_Click);
            // 
            // quảnLýTổBộMônToolStripMenuItem
            // 
            this.quảnLýTổBộMônToolStripMenuItem.Name = "quảnLýTổBộMônToolStripMenuItem";
            this.quảnLýTổBộMônToolStripMenuItem.Size = new System.Drawing.Size(174, 22);
            this.quảnLýTổBộMônToolStripMenuItem.Text = "Quản lý tổ bộ môn";
            this.quảnLýTổBộMônToolStripMenuItem.Click += new System.EventHandler(this.quảnLýTổBộMônToolStripMenuItem_Click);
            // 
            // đàoTạoToolStripMenuItem
            // 
            this.đàoTạoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.quảnLýMônHọcToolStripMenuItem,
            this.thờiKhóaBiểuVàLịchDạyToolStripMenuItem,
            this.phòngHọcVàThiếtBịToolStripMenuItem});
            this.đàoTạoToolStripMenuItem.Name = "đàoTạoToolStripMenuItem";
            this.đàoTạoToolStripMenuItem.Size = new System.Drawing.Size(60, 20);
            this.đàoTạoToolStripMenuItem.Text = "Đào tạo";
            // 
            // quảnLýMônHọcToolStripMenuItem
            // 
            this.quảnLýMônHọcToolStripMenuItem.Name = "quảnLýMônHọcToolStripMenuItem";
            this.quảnLýMônHọcToolStripMenuItem.Size = new System.Drawing.Size(211, 22);
            this.quảnLýMônHọcToolStripMenuItem.Text = "Quản lý môn học";
            this.quảnLýMônHọcToolStripMenuItem.Click += new System.EventHandler(this.quảnLýMônHọcToolStripMenuItem_Click);
            // 
            // thờiKhóaBiểuVàLịchDạyToolStripMenuItem
            // 
            this.thờiKhóaBiểuVàLịchDạyToolStripMenuItem.Name = "thờiKhóaBiểuVàLịchDạyToolStripMenuItem";
            this.thờiKhóaBiểuVàLịchDạyToolStripMenuItem.Size = new System.Drawing.Size(211, 22);
            this.thờiKhóaBiểuVàLịchDạyToolStripMenuItem.Text = "Thời khóa biểu và lịch dạy";
            this.thờiKhóaBiểuVàLịchDạyToolStripMenuItem.Click += new System.EventHandler(this.thờiKhóaBiểuVàLịchDạyToolStripMenuItem_Click);
            // 
            // phòngHọcVàThiếtBịToolStripMenuItem
            // 
            this.phòngHọcVàThiếtBịToolStripMenuItem.Name = "phòngHọcVàThiếtBịToolStripMenuItem";
            this.phòngHọcVàThiếtBịToolStripMenuItem.Size = new System.Drawing.Size(211, 22);
            this.phòngHọcVàThiếtBịToolStripMenuItem.Text = "Phòng học và thiết bị";
            this.phòngHọcVàThiếtBịToolStripMenuItem.Click += new System.EventHandler(this.phòngHọcVàThiếtBịToolStripMenuItem_Click);
            // 
            // khảoThíVàKếtQuảToolStripMenuItem
            // 
            this.khảoThíVàKếtQuảToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.quảnLýĐiểmSốToolStripMenuItem,
            this.hạnhKiểmVàRènLuyệnToolStripMenuItem,
            this.lịchThiToolStripMenuItem});
            this.khảoThíVàKếtQuảToolStripMenuItem.Name = "khảoThíVàKếtQuảToolStripMenuItem";
            this.khảoThíVàKếtQuảToolStripMenuItem.Size = new System.Drawing.Size(121, 20);
            this.khảoThíVàKếtQuảToolStripMenuItem.Text = "Khảo thí và Kết quả";
            // 
            // quảnLýĐiểmSốToolStripMenuItem
            // 
            this.quảnLýĐiểmSốToolStripMenuItem.Name = "quảnLýĐiểmSốToolStripMenuItem";
            this.quảnLýĐiểmSốToolStripMenuItem.Size = new System.Drawing.Size(199, 22);
            this.quảnLýĐiểmSốToolStripMenuItem.Text = "Quản lý điểm số";
            this.quảnLýĐiểmSốToolStripMenuItem.Click += new System.EventHandler(this.quảnLýĐiểmSốToolStripMenuItem_Click);
            // 
            // hạnhKiểmVàRènLuyệnToolStripMenuItem
            // 
            this.hạnhKiểmVàRènLuyệnToolStripMenuItem.Name = "hạnhKiểmVàRènLuyệnToolStripMenuItem";
            this.hạnhKiểmVàRènLuyệnToolStripMenuItem.Size = new System.Drawing.Size(199, 22);
            this.hạnhKiểmVàRènLuyệnToolStripMenuItem.Text = "Hạnh kiểm và rèn luyện";
            this.hạnhKiểmVàRènLuyệnToolStripMenuItem.Click += new System.EventHandler(this.hạnhKiểmVàRènLuyệnToolStripMenuItem_Click);
            // 
            // lịchThiToolStripMenuItem
            // 
            this.lịchThiToolStripMenuItem.Name = "lịchThiToolStripMenuItem";
            this.lịchThiToolStripMenuItem.Size = new System.Drawing.Size(199, 22);
            this.lịchThiToolStripMenuItem.Text = "Lịch thi";
            this.lịchThiToolStripMenuItem.Click += new System.EventHandler(this.lịchThiToolStripMenuItem_Click);
            // 
            // hànhChínhVàTàiVụToolStripMenuItem
            // 
            this.hànhChínhVàTàiVụToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.quảnLýHọcPhíToolStripMenuItem,
            this.quảnLýThôngBáoToolStripMenuItem,
            this.quảnLýPhúcKhảoToolStripMenuItem});
            this.hànhChínhVàTàiVụToolStripMenuItem.Name = "hànhChínhVàTàiVụToolStripMenuItem";
            this.hànhChínhVàTàiVụToolStripMenuItem.Size = new System.Drawing.Size(129, 20);
            this.hànhChínhVàTàiVụToolStripMenuItem.Text = "Hành chính và Tài vụ";
            // 
            // quảnLýHọcPhíToolStripMenuItem
            // 
            this.quảnLýHọcPhíToolStripMenuItem.Name = "quảnLýHọcPhíToolStripMenuItem";
            this.quảnLýHọcPhíToolStripMenuItem.Size = new System.Drawing.Size(174, 22);
            this.quảnLýHọcPhíToolStripMenuItem.Text = "Quản lý học phí";
            this.quảnLýHọcPhíToolStripMenuItem.Click += new System.EventHandler(this.quảnLýHọcPhíToolStripMenuItem_Click);
            // 
            // quảnLýThôngBáoToolStripMenuItem
            // 
            this.quảnLýThôngBáoToolStripMenuItem.Name = "quảnLýThôngBáoToolStripMenuItem";
            this.quảnLýThôngBáoToolStripMenuItem.Size = new System.Drawing.Size(174, 22);
            this.quảnLýThôngBáoToolStripMenuItem.Text = "Quản lý thông báo";
            this.quảnLýThôngBáoToolStripMenuItem.Click += new System.EventHandler(this.quảnLýThôngBáoToolStripMenuItem_Click);
            // 
            // quảnLýPhúcKhảoToolStripMenuItem
            // 
            this.quảnLýPhúcKhảoToolStripMenuItem.Name = "quảnLýPhúcKhảoToolStripMenuItem";
            this.quảnLýPhúcKhảoToolStripMenuItem.Size = new System.Drawing.Size(174, 22);
            this.quảnLýPhúcKhảoToolStripMenuItem.Text = "Quản lý phúc khảo";
            this.quảnLýPhúcKhảoToolStripMenuItem.Click += new System.EventHandler(this.quảnLýPhúcKhảoToolStripMenuItem_Click);
            // 
            // hệThốngVàChínhSáchToolStripMenuItem
            // 
            this.hệThốngVàChínhSáchToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.quảnLýHọcSinhToolStripMenuItem,
            this.quảnLýĐốiTượngƯuTiênToolStripMenuItem,
            this.quảnLýTàiKhoảnToolStripMenuItem});
            this.hệThốngVàChínhSáchToolStripMenuItem.Name = "hệThốngVàChínhSáchToolStripMenuItem";
            this.hệThốngVàChínhSáchToolStripMenuItem.Size = new System.Drawing.Size(144, 20);
            this.hệThốngVàChínhSáchToolStripMenuItem.Text = "Hệ thống và chính sách";
            // 
            // quảnLýHọcSinhToolStripMenuItem
            // 
            this.quảnLýHọcSinhToolStripMenuItem.Name = "quảnLýHọcSinhToolStripMenuItem";
            this.quảnLýHọcSinhToolStripMenuItem.Size = new System.Drawing.Size(210, 22);
            this.quảnLýHọcSinhToolStripMenuItem.Text = "Quản lý học sinh";
            this.quảnLýHọcSinhToolStripMenuItem.Click += new System.EventHandler(this.quảnLýHọcSinhToolStripMenuItem_Click);
            // 
            // quảnLýĐốiTượngƯuTiênToolStripMenuItem
            // 
            this.quảnLýĐốiTượngƯuTiênToolStripMenuItem.Name = "quảnLýĐốiTượngƯuTiênToolStripMenuItem";
            this.quảnLýĐốiTượngƯuTiênToolStripMenuItem.Size = new System.Drawing.Size(210, 22);
            this.quảnLýĐốiTượngƯuTiênToolStripMenuItem.Text = "Quản lý đối tượng ưu tiên";
            this.quảnLýĐốiTượngƯuTiênToolStripMenuItem.Click += new System.EventHandler(this.quảnLýĐốiTượngƯuTiênToolStripMenuItem_Click);
            // 
            // quảnLýTàiKhoảnToolStripMenuItem
            // 
            this.quảnLýTàiKhoảnToolStripMenuItem.Name = "quảnLýTàiKhoảnToolStripMenuItem";
            this.quảnLýTàiKhoảnToolStripMenuItem.Size = new System.Drawing.Size(210, 22);
            this.quảnLýTàiKhoảnToolStripMenuItem.Text = "Quản lý tài khoản";
            this.quảnLýTàiKhoảnToolStripMenuItem.Click += new System.EventHandler(this.quảnLýTàiKhoảnToolStripMenuItem_Click);
            // 
            // label1
            // 
            this.label1.AllowDrop = true;
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.Highlight;
            this.label1.Location = new System.Drawing.Point(360, 360);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(574, 37);
            this.label1.TabIndex = 2;
            this.label1.Text = "CHÀO MỪNG ĐẾN VỚI HỆ THỐNG QUẢN LÝ";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1264, 681);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menuStrip2);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Hệ Thống Quản Lý Trường THPT";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip2.ResumeLayout(false);
            this.menuStrip2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.MenuStrip menuStrip2;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem editToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem đăngXuấtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thoátToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quảnLýLớpHọcToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quảnLýGiáoViênToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quảnLýTổBộMônToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem đàoTạoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quảnLýMônHọcToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thờiKhóaBiểuVàLịchDạyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem phòngHọcVàThiếtBịToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem khảoThíVàKếtQuảToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quảnLýĐiểmSốToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hạnhKiểmVàRènLuyệnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lịchThiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hànhChínhVàTàiVụToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quảnLýHọcPhíToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quảnLýThôngBáoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quảnLýPhúcKhảoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hệThốngVàChínhSáchToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quảnLýHọcSinhToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quảnLýĐốiTượngƯuTiênToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quảnLýTàiKhoảnToolStripMenuItem;
        private System.Windows.Forms.Label label1;
    }
}